<?php
class userControllerCsp extends controllerCsp {
	
}
