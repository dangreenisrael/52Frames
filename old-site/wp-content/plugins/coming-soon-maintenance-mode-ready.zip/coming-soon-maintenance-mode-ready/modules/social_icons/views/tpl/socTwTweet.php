<a href="https://twitter.com/share" class="twitter-share-button" 
   data-url="<?php echo $this->currentUrl?>"
   data-lang="<?php echo $this->langIso2Code?>" 
   data-size="<?php echo $this->optsModel->get('soc_tw_tweet_size')?>" 
   data-count="<?php echo $this->optsModel->get('soc_tw_tweet_count')?>">Tweet</a>