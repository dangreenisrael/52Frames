<a href="https://twitter.com/<?php echo $this->optsModel->get('soc_tw_link_account')?>">
	<img src="<?php echo $this->getSocImgPath('Twitter-link.png')?>" />
</a>
