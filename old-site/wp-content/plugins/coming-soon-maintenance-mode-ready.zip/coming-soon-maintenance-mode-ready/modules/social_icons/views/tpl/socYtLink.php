<a href="http://www.youtube.com/user/<?php echo $this->optsModel->get('soc_yt_account')?>">
	<img src="<?php echo $this->getSocImgPath('Youtube-link.png')?>" />
</a>