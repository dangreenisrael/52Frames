<a href="http://instagram.com/<?php echo $this->optsModel->get('soc_im_account')?>?ref=badge">
	<img src="<?php echo $this->getSocImgPath('Instagram-link.png')?>" />
</a>