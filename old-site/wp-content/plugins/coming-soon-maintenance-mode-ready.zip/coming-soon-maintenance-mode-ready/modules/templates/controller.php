<?php
class templatesController extends controllerCsp {

}
?>
