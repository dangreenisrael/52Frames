<!DOCTYPE HTML>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<title><?php langCsp::_e('Under Construction')?></title>
	</head>
	<body>
		<center>
			<h2><?php langCsp::_e('Our Website is Under Construction')?></h2>
		</center>
	</body>
</html>
