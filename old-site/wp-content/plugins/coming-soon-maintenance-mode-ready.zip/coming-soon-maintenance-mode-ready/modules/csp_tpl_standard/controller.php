<?php
class csp_tpl_standardControllerCsp extends controllerCsp {
	
}