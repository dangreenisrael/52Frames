<?php
class logControllerCsp extends controllerCsp {
    
}