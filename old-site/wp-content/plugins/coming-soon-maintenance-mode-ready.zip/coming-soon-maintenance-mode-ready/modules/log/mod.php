<?php
class logCsp extends moduleCsp {
    
}