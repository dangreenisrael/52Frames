<?php
class promo_readyViewCsp extends viewCsp {
    public function displayAdminFooter() {
        parent::display('adminFooter');
    }
}
