<?php
class promo_readyControllerCsp extends controllerCsp {
    
}