<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'contest_con2014test');

/** MySQL database username */
define('DB_USER', 'contest_efi');

/** MySQL database password */
define('DB_PASSWORD', 'Efi052714656e!');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '1<P-3nGDSr0IE%-L@:L{g?Oim&Z!y5,v*54j-VZzK|=hM-iJ]_ )QW;QcB*Lz&k@');
define('SECURE_AUTH_KEY',  '#r46[--wpcuESa;^n5|1A&@KAp3Cs2?&cyIDuDQ-T`]DJpZ`UPw5*j.u5*|*mEF2');
define('LOGGED_IN_KEY',    '8,./WsQD|-m3A$OJg&O`UXW)^u0C-w KfWFl?xVA+#UrRq6p%Lz)U+`c<=`YTd o');
define('NONCE_KEY',        '({|yi![tA?/t.s|]5KTy+QBykt8E[(VMSuXa3}PoIgDoPDnu#3>@`A-<,I*lY/Wi');
define('AUTH_SALT',        '.4guE5daXo75XrU-wIJ@AT~&=&[(i}gQW]>H=sqydT7H{gGfk3=rh4Xe6jaD|SMf');
define('SECURE_AUTH_SALT', '6G>=G-}M>PR-sA.K<gWt2RRHM|vUA5Lom3uJW+kL;5?JU7f:s~;%.yyWo$E(Jf.<');
define('LOGGED_IN_SALT',   'qVy+2!B@WJzQm)^n|4-y$!%OL 0fu(!jgWu*kuRf-_E]AX7)J}d00Ap+-W*I]R#]');
define('NONCE_SALT',       'BfYZEyk>hW-[Z3BO>ridl${jEk-KnR+JB^P2* $Jjo.+uP4-|>O@eT/7A-pP/ZQD');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
